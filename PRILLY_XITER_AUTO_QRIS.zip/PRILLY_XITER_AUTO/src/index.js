const CATALOG = {
  "HG MODES": { "1 DAY": 13000, "7 DAY": 40000, "10 DAY": 50000, "30 DAY": 80000 },
  "REZZX": { "1 JAM": 4000, "2 JAM": 5000, "3 JAM": 7000, "6 JAM": 14000, "12 JAM": 18000, "1 HARI": 25000, "3 HARI": 40000, "7 HARI": 60000, "10 HARI": 85000 },
  "DRIP WIRE": { "3 JAM": 6000, "6 JAM": 8000, "12 JAM": 10000, "1 HARI": 18000, "7 HARI": 55000, "30 HARI": 100000 },
  "PHANTOM": { "1 JAM": 4000, "3 JAM": 6000, "6 JAM": 12000, "1 HARI": 19000, "3 HARI": 35000 },
  "DRIP CLIENT": { "1 DAY": 10000, "3 DAY": 20000, "7 DAY": 40000, "15 DAY": 60000, "30 DAY": 100000 },
  "BR MODES": { "1 HARI": 15000, "10 HARI": 65000, "30 HARI": 100000 },
  "PATO MODES": { "3 DAY": 30000, "7 DAY": 50000, "15 DAY": 100000 },
  "PRIME HOOK": { "1 DAY": 10000, "3 DAY": 20000, "7 DAY": 40000 },
  "SILENT CHEAT": { "1 DAY": 10000, "3 DAY": 25000, "7 DAY": 45000, "14 DAY": 65000, "30 DAY": 95000 },
  "XREG": { "1 JAM": 5000, "3 JAM": 7000, "6 JAM": 10000, "12 JAM": 15000, "1 HARI": 17000, "3 HARI": 35000, "7 HARI": 55000, "30 HARI": 100000 }
};

const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});

function corsHeaders(request) {
  const origin = request.headers.get("Origin");
  return origin ? { "access-control-allow-origin": origin, "vary": "Origin" } : {};
}

function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let mismatch = 0;
  for (let i = 0; i < a.length; i++) mismatch |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return mismatch === 0;
}

async function createOrder(request, env) {
  if (!env.DB || !env.XENDIT_SECRET_KEY) return json({ error: "Server pembayaran belum dikonfigurasi." }, 503);
  let body;
  try { body = await request.json(); } catch { return json({ error: "Format permintaan tidak valid." }, 400); }

  const product = String(body.product || "").trim();
  const duration = String(body.duration || "").trim();
  const amount = CATALOG[product]?.[duration];
  if (!amount) return json({ error: "Produk atau durasi tidak ditemukan." }, 400);
  if (amount < 1 || amount > 10000000) return json({ error: "Nominal berada di luar batas QRIS." }, 400);

  const id = crypto.randomUUID();
  const referenceId = `PRILLY-${id}`;
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString();

  await env.DB.prepare(`INSERT INTO orders (id, product, duration, amount, xendit_reference_id, status)
    VALUES (?, ?, ?, ?, ?, 'PENDING')`).bind(id, product, duration, amount, referenceId).run();

  const payload = {
    reference_id: referenceId,
    type: "PAY",
    country: "ID",
    currency: "IDR",
    request_amount: amount,
    capture_method: "AUTOMATIC",
    channel_code: "QRIS",
    channel_properties: { expires_at: expiresAt },
    description: `PRILLY XITER - ${product} ${duration}`,
    metadata: { order_id: id, product, duration }
  };

  let xenditResponse;
  try {
    const basic = btoa(`${env.XENDIT_SECRET_KEY}:`);
    const response = await fetch("https://api.xendit.co/v3/payment_requests", {
      method: "POST",
      headers: {
        "Authorization": `Basic ${basic}`,
        "Content-Type": "application/json",
        "api-version": "2024-11-11"
      },
      body: JSON.stringify(payload)
    });
    xenditResponse = await response.json();
    if (!response.ok) {
      await env.DB.prepare("UPDATE orders SET status='FAILED', updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(id).run();
      console.error("Xendit create payment error", response.status, JSON.stringify(xenditResponse));
      return json({ error: "Xendit gagal membuat QRIS. Periksa status akun, API key, dan channel QRIS." }, 502);
    }
  } catch (error) {
    await env.DB.prepare("UPDATE orders SET status='FAILED', updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(id).run();
    console.error("Xendit network error", error);
    return json({ error: "Tidak dapat menghubungi layanan pembayaran." }, 502);
  }

  const qrAction = (xenditResponse.actions || []).find(a => a.descriptor === "QR_STRING" || a.descriptor === "QR_CODE");
  const qrString = qrAction?.value;
  if (!xenditResponse.payment_request_id || !qrString) {
    await env.DB.prepare("UPDATE orders SET status='FAILED', updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(id).run();
    console.error("Xendit response missing QR action", JSON.stringify(xenditResponse));
    return json({ error: "Xendit tidak mengembalikan data QRIS. Periksa konfigurasi QRIS pada dashboard Xendit." }, 502);
  }

  await env.DB.prepare(`UPDATE orders SET xendit_payment_request_id=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .bind(xenditResponse.payment_request_id, id).run();

  return json({ orderId: id, amount, currency: "IDR", qrString, expiresAt });
}

async function getOrder(id, env) {
  const row = await env.DB.prepare("SELECT id, product, duration, amount, status, created_at, paid_at FROM orders WHERE id=?")
    .bind(id).first();
  if (!row) return json({ error: "Pesanan tidak ditemukan." }, 404);
  return json({ orderId: row.id, product: row.product, duration: row.duration, amount: row.amount, status: row.status, createdAt: row.created_at, paidAt: row.paid_at });
}

async function xenditWebhook(request, env) {
  if (!env.XENDIT_WEBHOOK_TOKEN) return json({ error: "Webhook token belum dikonfigurasi." }, 503);
  const token = request.headers.get("x-callback-token") || "";
  if (!safeEqual(token, env.XENDIT_WEBHOOK_TOKEN)) return json({ error: "Unauthorized webhook." }, 401);

  let event;
  try { event = await request.json(); } catch { return json({ error: "Invalid JSON." }, 400); }
  const data = event.data || {};
  const referenceId = data.reference_id;
  if (!referenceId) return json({ received: true, ignored: true });

  const order = await env.DB.prepare(`SELECT id, amount, status, xendit_payment_request_id FROM orders WHERE xendit_reference_id=?`)
    .bind(referenceId).first();
  if (!order) return json({ received: true, ignored: true });
  if (order.status === "PAID") return json({ received: true, duplicate: true });

  const validAmount = Number(data.request_amount ?? data.capture_amount ?? 0) === Number(order.amount);
  const validCurrency = data.currency === "IDR";
  const validChannel = data.channel_code === "QRIS";
  const validRequest = !order.xendit_payment_request_id || data.payment_request_id === order.xendit_payment_request_id;

  if (event.event === "payment.capture" && data.status === "SUCCEEDED" && validAmount && validCurrency && validChannel && validRequest) {
    await env.DB.prepare(`UPDATE orders SET status='PAID', xendit_payment_id=?, paid_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP
      WHERE id=? AND status='PENDING' AND amount=?`).bind(data.payment_id || null, order.id, order.amount).run();
  } else if (event.event === "payment_request.expiry" || event.event === "payment.failure" || data.status === "FAILED" || data.status === "EXPIRED") {
    const next = event.event === "payment_request.expiry" || data.failure_code === "PAYMENT_REQUEST_EXPIRED" || data.status === "EXPIRED" ? "EXPIRED" : "FAILED";
    await env.DB.prepare("UPDATE orders SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='PENDING'").bind(next, order.id).run();
  }
  return json({ received: true });
}

async function adminOrders(request, env) {
  if (!env.ADMIN_TOKEN) return json({ error: "Admin token belum dikonfigurasi." }, 503);
  const auth = request.headers.get("authorization") || "";
  if (!safeEqual(auth, `Bearer ${env.ADMIN_TOKEN}`)) return json({ error: "Unauthorized." }, 401);
  const result = await env.DB.prepare(`SELECT id, product, duration, amount, status, created_at, paid_at, xendit_payment_id
    FROM orders ORDER BY created_at DESC LIMIT 100`).all();
  return json({ orders: result.results || [] });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    let response;
    try {
      if (request.method === "OPTIONS" && path.startsWith("/api/")) {
        response = new Response(null, { status: 204, headers: { "access-control-allow-methods": "GET,POST,OPTIONS", "access-control-allow-headers": "Content-Type,Authorization", "access-control-max-age": "86400" } });
      } else if (path === "/api/orders" && request.method === "POST") {
        response = await createOrder(request, env);
      } else if (path.startsWith("/api/orders/") && request.method === "GET") {
        response = await getOrder(decodeURIComponent(path.slice("/api/orders/".length)), env);
      } else if (path === "/api/xendit/webhook" && request.method === "POST") {
        response = await xenditWebhook(request, env);
      } else if (path === "/api/admin/orders" && request.method === "GET") {
        response = await adminOrders(request, env);
      } else if (path.startsWith("/api/")) {
        response = json({ error: "Endpoint tidak ditemukan." }, 404);
      } else {
        response = await env.ASSETS.fetch(request);
      }
    } catch (error) {
      console.error("Unhandled worker error", error);
      response = json({ error: "Terjadi kesalahan server." }, 500);
    }

    const headers = new Headers(response.headers);
    for (const [key, value] of Object.entries(corsHeaders(request))) headers.set(key, value);
    headers.set("x-content-type-options", "nosniff");
    headers.set("referrer-policy", "strict-origin-when-cross-origin");
    headers.set("x-frame-options", "DENY");
    return new Response(response.body, { status: response.status, headers });
  }
};
